#include <iostream>
#include <string>

using namespace std;

int main(){

    string simbolo="* * * * * * * *";
    string simbolo2=" * * * * * * * *";

    cout << simbolo << endl;
    cout << simbolo2 << endl;
    cout << simbolo << endl;
    cout << simbolo2 << endl;
    cout << simbolo << endl;
    cout << simbolo2 << endl;
    cout << simbolo << endl;
    cout << simbolo2 << endl;

    return 0;

}