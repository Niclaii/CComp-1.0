#include <iostream>
#include <string>

using namespace std;

int main(){

    int numero1{1};
    int numero2{2};
    int numero3{0};
    int numero4{4};
    int numero5{3};

    if(numero1<numero2 && numero1<numero3 && numero1<numero4 && numero1<numero5){
        cout << numero1 << "\n" << endl;
    }
    if(numero2<numero1 && numero2<numero3 && numero2<numero4 && numero2<numero5){
        cout << numero2 << "\n" << endl;}
    
    if(numero3<numero1 && numero3<numero2 && numero3<numero4 && numero3<numero5){
        cout << numero3 << "\n" << endl;}
    
    if(numero4<numero2 && numero4<numero3 && numero4<numero1 && numero4<numero5){
        cout << numero4 << "\n" << endl;}
    
    if(numero5<numero1 && numero5<numero3 && numero5<numero4 && numero5<numero2){
        cout << numero5 << "\n" << endl;}

    if(numero1>numero2 && numero1>numero3 && numero1>numero4 && numero1>numero5){
        cout << numero1 << "\n" << endl;;
    }
    if(numero2>numero1 && numero2>numero3 && numero2>numero4 && numero2>numero5){
        cout << numero2 << "\n" << endl;}
    
    if(numero3>numero1 && numero3>numero2 && numero3>numero4 && numero3>numero5){
        cout << numero3 << "\n" << endl;}
    
    if(numero4>numero2 && numero4>numero3 && numero4>numero1 && numero4>numero5){
        cout << numero4 << "\n" << endl;}
    
    if(numero5>numero1 && numero5>numero3 && numero5>numero4 && numero5>numero2){
        cout << numero5 << "\n" << endl;}


}