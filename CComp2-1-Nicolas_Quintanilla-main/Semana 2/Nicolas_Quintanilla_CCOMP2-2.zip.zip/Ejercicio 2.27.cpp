#include <iostream>
#include <string>

using namespace std;

int main(){

    cout << 'A' << endl; 
    cout << static_cast<int>('Ñ') << endl;

}