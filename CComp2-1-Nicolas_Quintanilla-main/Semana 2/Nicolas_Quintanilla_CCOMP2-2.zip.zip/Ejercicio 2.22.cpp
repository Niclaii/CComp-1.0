#include <iostream>
#include <string>

using namespace std;

int main(){

cout << "*****\n****\n***\n**\n*\n " << endl; // Crea una piramide invertida de 90°
}