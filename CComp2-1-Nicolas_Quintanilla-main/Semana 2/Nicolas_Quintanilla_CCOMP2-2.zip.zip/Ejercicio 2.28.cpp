#include <iostream>
#include <string>

using namespace std;

int main(){

    string numeros{0};

    cout << "Escribe 4 enteros: ";
    cin >> numeros;

    string str(numeros);
    cout << str.at(3) << str.at(2) << str.at(1) << str.at(0) << endl;

    return 0;

}