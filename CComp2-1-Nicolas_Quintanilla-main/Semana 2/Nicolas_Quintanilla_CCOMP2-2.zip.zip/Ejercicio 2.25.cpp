#include <iostream>
#include <string>

using namespace std;

int main(){

    int numero1{2};
    int numero2{4};
    int numero3{8}; 

    if (numero3%numero1==0){
        cout << numero1 << " es divisor de " << numero3 << endl;
     }
    else
    {
        cout << numero1 << " no es divisor de " << numero3 << endl;
    }
    
    if (numero3%numero2==0){
        cout << numero2 << " es divisor de " << numero3 << endl;
     }
    else
    {
        cout << numero2 << " no es divisor de " << numero3 << endl;
    }

    return 0;
}