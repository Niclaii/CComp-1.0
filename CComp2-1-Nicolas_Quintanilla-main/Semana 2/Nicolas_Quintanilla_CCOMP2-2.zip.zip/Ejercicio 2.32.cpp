#include <iostream>
#include <string>

using namespace std;

int main(){

    int edad{0};

    cout << "ingrese la edad: " << endl;
    cin >> edad;

    float MHR1 = 220 - edad;
    float MHR2 = 208 - (0.7*edad);
    float MHR3 = 207 - (0.7*edad);
    float MHR4 = 211 - (0.64*edad);

    if (MHR1>MHR2 && MHR1>MHR3 && MHR1>MHR4){
        cout << MHR1 << endl;
    }
    if (MHR2>MHR1 && MHR2>MHR3 && MHR2>MHR4){
        cout << MHR2 << endl;
    }
    if (MHR3>MHR2 && MHR3>MHR1 && MHR3>MHR4){
        cout << MHR3 << endl;
    }
    if (MHR4>MHR2 && MHR4>MHR3 && MHR4>MHR1){
        cout << MHR4 << endl;
    }
    if (MHR1<MHR2 && MHR1<MHR3 && MHR1<MHR4){
        cout << MHR1 << endl;
    }
    if (MHR2<MHR1 && MHR2<MHR3 && MHR2<MHR4){
        cout << MHR2 << endl;
    }
    if (MHR3<MHR2 && MHR3<MHR1 && MHR3<MHR4){
        cout << MHR3 << endl;
    }
    if (MHR4<MHR2 && MHR4<MHR3 && MHR4<MHR1){
        cout << MHR4 << endl;
    }
   

    return 0;

}