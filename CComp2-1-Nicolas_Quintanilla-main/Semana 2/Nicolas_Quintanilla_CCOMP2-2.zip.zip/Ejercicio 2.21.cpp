#include <iostream>
#include <string>

using namespace std;

int main(){

    cout << "  CCC   +      + " << endl;
    cout << " C      +      +" << endl;
    cout << "C     +++++  +++++" << endl;
    cout << " C      +      +" << endl;
    cout << "  CCC   +      + " << endl;
}