#include <iostream> 
#include <string>

int main(){
    using namespace std;
    int radio{0};
    int pi{3};

    std::cout << "Escribe el radio: " << endl;
    std::cin >> radio;

    int diametro = radio * 2;
    int circunferencia = pi * diametro;
    int area = 2 * pi * radio;

    std::cout << "El diametro es: " << diametro << endl;
    std::cout << "La circunferencia es: " << circunferencia << endl;
    std::cout << "El área es: " << area << endl;

    return 0;

}