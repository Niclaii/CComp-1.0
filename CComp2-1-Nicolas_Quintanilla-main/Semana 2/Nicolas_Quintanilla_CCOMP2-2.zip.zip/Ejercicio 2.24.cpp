#include <iostream>
#include <string>

using namespace std;

int main(){

    int numero1{5};
    int numero2{8};

    if (numero1%2==0){
        cout << numero1 << " Es par " << endl;
    }
    else
    {
        cout << numero1 << " Es impar" << endl;
    }

    if (numero2%2==0){
        cout << numero2 << " Es par " << endl;
    }
    else
    {
        cout << numero2 << " Es impar" << endl;
    }    
    
    int suma = numero1 + numero2;

    if (suma%2==0){
        cout << suma << " Es par" << endl;
    }
    else 
    {
        cout << suma << " Es impar" << endl;
    }

    return 0;

}