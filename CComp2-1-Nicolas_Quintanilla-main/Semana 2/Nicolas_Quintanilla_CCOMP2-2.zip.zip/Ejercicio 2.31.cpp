#include <iostream>
#include <string>

using namespace std;

int main(){

    int TmillasD{0};
    int CosteGasolina{0};
    int MillaspGalon{0};
    int TarifaP{0};
    int HerramientaspDia{0};

    cout << "Escriba el total de millas manejadas al dia: " << endl;
    cin >> TmillasD;

    cout << "Escriba el coste de gasolina: " << endl;
    cin >> CosteGasolina;

    cout << "Escriba las millas por galon aprox: " << endl;
    cin >> MillaspGalon;

    cout << "Escriba la tarifa del Estacionamiento: " << endl;
    cin >> TarifaP;

    cout << "Escriba las herramientas por dia: " << endl;
    cin >> HerramientaspDia;

    int consumo = TmillasD - MillaspGalon;
    
    int sum = CosteGasolina + TarifaP + HerramientaspDia + consumo; 

    cout << "El total que se esta ahorrando es: " << sum << endl;

    return 0;

}